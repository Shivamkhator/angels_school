from django.apps import AppConfig


class TailwindConfig(AppConfig):
    name = "tailwind"
